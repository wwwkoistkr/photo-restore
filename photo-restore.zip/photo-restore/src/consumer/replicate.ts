// =====================================================
// replicate.ts — Replicate GFPGAN 호출 + 폴링
// 모델: tencentarc/gfpgan (복원형 — 인물 동일성 보존)
// =====================================================
import type { Env } from "../shared/types";

// tencentarc/gfpgan 공개 버전 해시 (Replicate)
const GFPGAN_VERSION =
  "0fbacf7afc6c144e5be9767cff80f25aff23e52b0708f17e20f9879b2f21516c";

const POLL_INTERVAL_MS = 2_000;
const POLL_TIMEOUT_MS = 120_000;

interface Prediction {
  id: string;
  status: "starting" | "processing" | "succeeded" | "failed" | "canceled";
  output?: string | string[];
  error?: string | null;
}

export async function runGfpgan(
  env: Env,
  imageUrl: string,
  scale: number
): Promise<string> {
  // 1) prediction 생성
  const createRes = await fetch("https://api.replicate.com/v1/predictions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${env.REPLICATE_API_TOKEN}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      version: GFPGAN_VERSION,
      input: {
        img: imageUrl,
        version: "v1.4",
        scale: scale,
      },
    }),
  });

  if (!createRes.ok) {
    const txt = await createRes.text();
    throw new Error(`Replicate 생성 실패 HTTP ${createRes.status}: ${txt.slice(0, 200)}`);
  }

  const created = (await createRes.json()) as Prediction;

  // 2) 폴링 (2초 간격, 최대 120초)
  const deadline = Date.now() + POLL_TIMEOUT_MS;
  let p: Prediction = created;

  while (p.status === "starting" || p.status === "processing") {
    if (Date.now() > deadline) throw new Error("Replicate 타임아웃 (120초)");
    await sleep(POLL_INTERVAL_MS);

    const pollRes = await fetch(
      `https://api.replicate.com/v1/predictions/${p.id}`,
      { headers: { Authorization: `Bearer ${env.REPLICATE_API_TOKEN}` } }
    );
    if (!pollRes.ok) throw new Error(`Replicate 폴링 실패 HTTP ${pollRes.status}`);
    p = (await pollRes.json()) as Prediction;
  }

  if (p.status !== "succeeded") {
    throw new Error(`Replicate ${p.status}: ${p.error ?? "사유 미상"}`);
  }

  const out = Array.isArray(p.output) ? p.output[0] : p.output;
  if (!out) throw new Error("Replicate 출력 없음");
  return out;
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}
